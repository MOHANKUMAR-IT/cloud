package Cloud;

public interface Names {
	public void setName(String name);
	public String getName();
	public int getAge();
}