import java.rmi.*;
import java.util.*;
    
public class client {  
   private client() {}  
   public static void main(String[] args) {  
      try
        {
long beforeMem = Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
        long startTime = System.nanoTime();
            combinations access = (combinations)Naming.lookup("rmi://192.168.43.153:1900/cloud");
            System.out.println("Combinations calculator::->\n");
            System.out.print("N = ");
            Scanner scan = new Scanner(System.in);
            int n = scan.nextInt();
            System.out.print("R = ");
            int r = scan.nextInt();
            System.out.println(""); 
            long answer = access.nCr(n,r);
            System.out.print("Combinations of "+n+" given "+r+" objects is -> ");
            System.out.println(answer);
long endTime = System.nanoTime();
        long afterMem = Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
        System.out.println("Memory Usage: "+(afterMem-beforeMem));
        System.out.println("Time Taken: "+(endTime-startTime));
        }
        catch(Exception ae) 
        {
            System.out.println(ae);
        }
   } 
}