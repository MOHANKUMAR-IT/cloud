import java.rmi.*;
public interface combinations extends Remote{
    public long nCr(int N,int R) throws RemoteException;
}