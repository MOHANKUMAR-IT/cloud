import java.rmi.*;
import java.rmi.server.*;
public class combinationsQuery extends UnicastRemoteObject implements combinations{
    combinationsQuery() throws RemoteException{
        super();
    }
    long fact(int n,int r)
    {   
        int res = 1;   
        for (int i = n; i >n-r; i--)
            res = res * i;
        return res;
    }
    long fact(int n)
    {
        int res = 1;
        for (int i = 2; i<=n; i++)
            res = res * i;
        return res;
    }
    public long nCr(int N,int R) throws RemoteException{
        if(R>N)R=N-R;
        return fact(N,R) / fact(R);
    }
}